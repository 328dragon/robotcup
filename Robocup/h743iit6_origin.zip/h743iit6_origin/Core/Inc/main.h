/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32h7xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define SPI4_CS_Pin GPIO_PIN_3
#define SPI4_CS_GPIO_Port GPIOE
#define SPI5_CS_Pin GPIO_PIN_2
#define SPI5_CS_GPIO_Port GPIOC
#define SLEEP2_Pin GPIO_PIN_3
#define SLEEP2_GPIO_Port GPIOC
#define PH_2_Pin GPIO_PIN_3
#define PH_2_GPIO_Port GPIOH
#define TFT_RS_Pin GPIO_PIN_3
#define TFT_RS_GPIO_Port GPIOD
#define TFT_RST_Pin GPIO_PIN_4
#define TFT_RST_GPIO_Port GPIOD
#define TFT_CS_Pin GPIO_PIN_5
#define TFT_CS_GPIO_Port GPIOD
#define SPI1_CS_Pin GPIO_PIN_10
#define SPI1_CS_GPIO_Port GPIOG
#define SPI3_CS_Pin GPIO_PIN_15
#define SPI3_CS_GPIO_Port GPIOG
#define SLEEP1_Pin GPIO_PIN_3
#define SLEEP1_GPIO_Port GPIOB
#define SPI6_CS_Pin GPIO_PIN_8
#define SPI6_CS_GPIO_Port GPIOB
#define PH_1_Pin GPIO_PIN_9
#define PH_1_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */
#include "stepmotor.h"
#include "Emm_V5.h"
#include "string.h"
#include "stdio.h"

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
